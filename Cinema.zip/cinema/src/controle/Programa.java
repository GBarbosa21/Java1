package controle;
import view.JanelaSessao;

public class Programa {
    public static void main(String[] args) {
        JanelaSessao js = new JanelaSessao();

        js.setVisible(true);
    }
}