package controle;

import view.JanelaAluno;

public class Programa {
    public static void main(String[] args) {
        JanelaAluno ja = new JanelaAluno();

        ja.setVisible(true);
    }
}