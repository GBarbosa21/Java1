package view;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controle.ControleJanelaAluno;

public class JanelaAluno extends JFrame{

    private JPanel contentPane;
    private JTextField textNome;
    private JTextField textTurma;
    private JTextField textIdade;
    private JTextField textMedia;
    private ControleJanelaAluno cja =
            new ControleJanelaAluno();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    JanelaSessao frame = new JanelaSessao();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public JanelaAluno() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 276, 243);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JLabel lblCadastroDeAlun = new JLabel("CADASTRO DE Aluno\u00D5ES");
        lblCadastroDeAlun.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblCadastroDeAlun.setBounds(40, 11, 198, 24);
        contentPane.add(lblCadastroDeAlun);
       
        JLabel lblNome = new JLabel("NOME:");
        lblNome.setBounds(10, 49, 46, 14);
        contentPane.add(lblNome);
       
        JLabel lblTurma = new JLabel("TURMA:");
        lblTurma.setBounds(10, 74, 46, 14);
        contentPane.add(lblTurma);
       
        JLabel lblIdade = new JLabel("IDADE:");
        lblIdade.setBounds(10, 99, 46, 14);
        contentPane.add(lblIdade);
       
        JLabel lblMedia = new JLabel("MEDIA:");
        lblMedia.setBounds(10, 129, 46, 14);
        contentPane.add(lblMedia);
       
        textMedia = new JTextField();
        textMedia.setBounds(50, 46, 46, 20);
        contentPane.add(textNome);
        textNome.setColumns(10);
       
        textData = new JTextField();
        textData.setBounds(50, 71, 86, 20);
        contentPane.add(textData);
        textData.setColumns(10);
       
        textHora = new JTextField();
        textHora.setBounds(50, 99, 86, 20);
        contentPane.add(textHora);
        textHora.setColumns(10);
       
        textFilme = new JTextField();
        textFilme.setBounds(50, 126, 200, 20);
        contentPane.add(textFilme);
        textFilme.setColumns(10);
       
        JButton btnCadastrar = new JButton("CADASTRAR");
        btnCadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int Nome = Integer.parseInt(textNome.getText());
                String data = textData.getText();
                String hora = textHora.getText();
                String filme = textFilme.getText();
               
                cjs.incluirSessao(Nome, data, hora, filme);
               
                JOptionPane.showMessageDialog(null,
                        "Sess�o cadastrada com sucesso!");
               
                textNome.setText("");
                textData.setText("");
                textHora.setText("");
                textFilme.setText("");
            }
            JButton btnListar = new JButton("LISTAR");
            public void actionPerforme(ActionEvent d) {
            	String query = "SELECT Nome, data, hora, filme FROM sessao";
            	try {
                    // Estabelecer a conex�o com o banco de dados
                    Connection conn = DriverManager.getConnection(url, user, password);

                    // Criar uma declara��o SQL
                    Statement statement = conn.createStatement();

                    // Executar a consulta SQL e obter os resultados
                    ResultSet resultSet = statement.executeQuery(query);

                    // Iterar sobre os resultados e exibir as informa��es
                    while (resultSet.next()) {
                        String Nome = resultSet.getString("Nome");
                        String data = resultSet.getString("data");
                        String hora = resultSet.getString("hora");
                        String filme = resultSet.getString("filme");

                        System.out.println("Nome: " + Nome);
                        System.out.println("Data: " + data);
                        System.out.println("Hora: " + hora);
                        System.out.println("Filme: " + filme);
                        System.out.println("-----------------------");
                    }

                    // Fechar os recursos
                    resultSet.close();
                    statement.close();
                    conn.close();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
        
        
        
        
        btnCadastrar.setBounds(47, 154, 119, 23);
        contentPane.add(btnCadastrar);
    }
}