package controle;

import.dominio.DaoAluno;

public class ControleJanelaAluno {

	private aluno al = new aluno (null, 0, 0, null);
	private DaoAluno daoAl = new DaoAluno();
	
	public void incluirAluno(String nome, int turma, int idade, String media) {
        se.setNome(nome);
        se.setTurma(turma);
        se.setIdade(idade);
        se.setMedia(media);
       
    }
	
}
