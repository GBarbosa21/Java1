package dominio;

import java.sql.Connection;

public class DaoAluno {
	static final String url = "jdbc:postgresql://localhost:5432/escola";
	
	public void Listar(String nome, int turma, int idade, String media) {
        String sql = "SELECT * FROM public.aluno;";
   
        try {
            Connection conexao = DriverManager.getConnection(url, "escola", "");
            PreparedStatement inclusao = conexao.prepareStatement(sql);
            inclusao.execute();
        }
        catch (SQLException e) {
            System.out.println("Nao foi possivel acessar o BD");
            System.out.println(e);
        }
    }
	
}
